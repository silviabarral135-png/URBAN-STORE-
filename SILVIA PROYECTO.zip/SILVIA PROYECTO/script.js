// Catálogo de productos: cada objeto contiene los datos que se muestran en la tienda.
const products = [
  {id:1,name:"Polera Essential",category:"Poleras",price:120,oldPrice:150,image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=700&q=85",badge:"POPULAR"},
  {id:2,name:"Polera Oversize",category:"Poleras",price:150,oldPrice:null,image:"https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=700&q=85",badge:"NUEVO"},
  {id:3,name:"Pantalón Cargo",category:"Pantalones",price:230,oldPrice:null,image:"https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=700&q=85",badge:""},
  {id:4,name:"Jean Baggy",category:"Pantalones",price:260,oldPrice:290,image:"https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=700&q=85",badge:"-10%"},
  {id:5,name:"Sneakers Street",category:"Zapatillas",price:420,oldPrice:null,image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=85",badge:"DESTACADO"},
  {id:6,name:"Zapatillas Classic",category:"Zapatillas",price:380,oldPrice:null,image:"https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=700&q=85",badge:""},
  {id:7,name:"Gorra Urban",category:"Accesorios",price:85,oldPrice:100,image:"https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&w=700&q=85",badge:"-15%"},
  {id:8,name:"Mochila Daily",category:"Accesorios",price:190,oldPrice:null,image:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=700&q=85",badge:"NUEVO"}
];

let cart = JSON.parse(localStorage.getItem("urbanCart")) || [];
let activeCategory = "Todos";
let searchTerm = "";

const productGrid = document.querySelector("#product-grid");
const cartItems = document.querySelector("#cart-items");
const cartCount = document.querySelector("#cart-count");
const subtotalElement = document.querySelector("#cart-subtotal");
const totalElement = document.querySelector("#cart-total");
const toast = document.querySelector("#toast");

const money = value => `Bs ${value.toLocaleString("es-BO")}`;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2300);
}

function saveCart() {
  localStorage.setItem("urbanCart", JSON.stringify(cart));
}

function getVisibleProducts() {
  let result = [...products];

  if (activeCategory !== "Todos") {
    result = result.filter(product => product.category === activeCategory);
  }

  if (searchTerm) {
    result = result.filter(product =>
      `${product.name} ${product.category}`.toLowerCase().includes(searchTerm)
    );
  }

  const sort = document.querySelector("#sort-select").value;
  if (sort === "low") result.sort((a,b) => a.price - b.price);
  if (sort === "high") result.sort((a,b) => b.price - a.price);
  if (sort === "name") result.sort((a,b) => a.name.localeCompare(b.name));

  return result;
}

function renderProducts() {
  const visible = getVisibleProducts();
  document.querySelector("#results-count").textContent =
    `${visible.length} producto(s) encontrados`;

  if (!visible.length) {
    productGrid.innerHTML = `<div class="no-results">No encontramos productos con esa búsqueda.</div>`;
    return;
  }

  productGrid.innerHTML = visible.map(product => `
    <article class="product-card">
      <div class="product-image">
        <img src="${product.image}" alt="${product.name}" loading="lazy"
             onerror="this.src='https://placehold.co/600x700/f1f1ed/111?text=URBAN+STORE'">
        ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ""}
        <button class="quick-add" type="button" data-add="${product.id}">
          AGREGAR A MI BOLSA +
        </button>
      </div>
      <div class="product-info">
        <div>
          <h3>${product.name}</h3>
          <p class="product-category">${product.category}</p>
        </div>
        <p class="product-price">
          ${product.oldPrice ? `<span class="old-price">${money(product.oldPrice)}</span>` : ""}
          ${money(product.price)}
        </p>
      </div>
    </article>
  `).join("");
}

function addToCart(id) {
  const product = products.find(item => item.id === id);
  const existing = cart.find(item => item.id === id);

  if (existing) existing.quantity += 1;
  else cart.push({...product, quantity:1});

  saveCart();
  renderCart();
  showToast(`${product.name} agregado a tu bolsa`);
}

function changeQuantity(id, amount) {
  const item = cart.find(product => product.id === id);
  if (!item) return;
  item.quantity += amount;
  if (item.quantity <= 0) cart = cart.filter(product => product.id !== id);
  saveCart();
  renderCart();
}

function removeFromCart(id) {
  const item = cart.find(product => product.id === id);
  cart = cart.filter(product => product.id !== id);
  saveCart();
  renderCart();
  if (item) showToast(`${item.name} eliminado`);
}

function renderCart() {
  const quantity = cart.reduce((sum,item) => sum + item.quantity, 0);
  const total = cart.reduce((sum,item) => sum + item.price * item.quantity, 0);

  cartCount.textContent = quantity;
  document.querySelector("#summary-items").textContent = quantity;
  subtotalElement.textContent = money(total);
  totalElement.textContent = money(total);

  if (!cart.length) {
    cartItems.innerHTML = `
      <div class="empty-cart">
        <span>＋</span><h3>Tu bolsa está vacía</h3>
        <p>Explora la colección y agrega tus productos favoritos.</p>
        <a href="#coleccion">Ir a la colección →</a>
      </div>`;
    return;
  }

  cartItems.innerHTML = cart.map(item => `
    <article class="cart-item">
      <img class="cart-thumb" src="${item.image}" alt="${item.name}">
      <div><h4>${item.name}</h4><p>${item.category} · ${money(item.price)} c/u</p></div>
      <div class="quantity-control">
        <button type="button" data-minus="${item.id}" aria-label="Restar una unidad">−</button>
        <span>${item.quantity}</span>
        <button type="button" data-plus="${item.id}" aria-label="Agregar una unidad">+</button>
      </div>
      <div class="cart-item-price">${money(item.price * item.quantity)}</div>
      <button class="remove-button" type="button" data-remove="${item.id}">Eliminar</button>
    </article>
  `).join("");
}

// Eventos del catálogo y del carrito: delegación para elementos dinámicos.
productGrid.addEventListener("click", event => {
  const button = event.target.closest("[data-add]");
  if (button) addToCart(Number(button.dataset.add));
});

cartItems.addEventListener("click", event => {
  const minus = event.target.closest("[data-minus]");
  const plus = event.target.closest("[data-plus]");
  const remove = event.target.closest("[data-remove]");
  if (minus) changeQuantity(Number(minus.dataset.minus), -1);
  if (plus) changeQuantity(Number(plus.dataset.plus), 1);
  if (remove) removeFromCart(Number(remove.dataset.remove));
});

// Filtros por categoría.
document.querySelector("#filters").addEventListener("click", event => {
  const button = event.target.closest("[data-category]");
  if (!button) return;
  activeCategory = button.dataset.category;
  document.querySelectorAll(".filter-button").forEach(item =>
    item.classList.toggle("active", item === button)
  );
  renderProducts();
});

// Búsqueda y ordenamiento.
document.querySelector("#search-toggle").addEventListener("click", () => {
  document.querySelector("#search-panel").classList.toggle("hidden");
  document.querySelector("#search-input").focus();
});
document.querySelector("#search-input").addEventListener("input", event => {
  searchTerm = event.target.value.trim().toLowerCase();
  renderProducts();
});
document.querySelector("#sort-select").addEventListener("change", renderProducts);

// Menú adaptable para móviles.
document.querySelector("#menu-toggle").addEventListener("click", event => {
  const nav = document.querySelector("#main-nav");
  nav.classList.toggle("open");
  event.currentTarget.setAttribute("aria-expanded", nav.classList.contains("open"));
});
document.querySelectorAll("#main-nav a").forEach(link => {
  link.addEventListener("click", () => document.querySelector("#main-nav").classList.remove("open"));
});

// Formulario de contacto con validación HTML5.
document.querySelector("#contact-form").addEventListener("submit", event => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }
  const name = new FormData(form).get("name").trim();
  document.querySelector("#form-feedback").textContent =
    `¡Gracias, ${name}! Tu consulta fue registrada en esta demostración.`;
  form.reset();
});

// Resumen del pedido en una ventana modal.
const checkoutDialog = document.querySelector("#checkout-dialog");
document.querySelector("#checkout-button").addEventListener("click", () => {
  if (!cart.length) {
    showToast("Agrega al menos un producto antes de continuar");
    return;
  }

  const total = cart.reduce((sum,item) => sum + item.price * item.quantity, 0);
  document.querySelector("#checkout-details").innerHTML =
    cart.map(item => `<div class="checkout-line"><span>${item.name} × ${item.quantity}</span><strong>${money(item.price * item.quantity)}</strong></div>`).join("") +
    `<div class="checkout-line"><strong>TOTAL</strong><strong>${money(total)}</strong></div>`;
  checkoutDialog.showModal();
});

document.querySelector("#confirm-order").addEventListener("click", () => {
  checkoutDialog.close();
  showToast("Pedido de demostración confirmado. No se realizó ningún pago.");
});

// Suscripción demostrativa.
document.querySelector("#newsletter-form").addEventListener("submit", event => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }
  document.querySelector("#newsletter-feedback").textContent =
    "¡Gracias! Tu correo fue validado en esta demostración.";
  form.reset();
});

renderProducts();
renderCart();
